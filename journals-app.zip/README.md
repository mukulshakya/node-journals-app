# node-journals-app

- run `npm install` to install all the required modules.
- run `npm start` to start server.
- navigate to `127.0.0.1:3000`.
- `login` or `register` to use.
- you can login using `ms123`:`1234` to view sample journals.
